angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signup1', {
      templateUrl: 'templates/signup1.html',
    url: '/signup_one',
    controller: 'signup1Ctrl'
  })

  .state('signup2', {
    url: '/signup_two',
    templateUrl: 'templates/signup2.html',
    controller: 'signup2Ctrl'
  })

  .state('signup3', {
    url: '/signup_three',
    templateUrl: 'templates/signup3.html',
    controller: 'signup3Ctrl'
  })

  .state('signup4', {
    url: '/signup_four',
    templateUrl: 'templates/signup4.html',
    controller: 'signup4Ctrl'
  })

  .state('signup5', {
    url: '/signup_end',
    templateUrl: 'templates/signup5.html',
    controller: 'signup5Ctrl'
  })

$urlRouterProvider.otherwise('/login')


});